#ifndef DIAPORAMA_H
#define DIAPORAMA_H

#include <vector>
#include "Image.h"

using std::vector;

// repr�sente des images dans un diaporama
// mPositionDansDiaporama : position de l'image dans le diaporama
// mPositionDansImagesChargees : position de l'image dans le vecteur images chargees du lecteur
struct LocalisationsImagesDiaporama
{
	unsigned short int mPositionDansDiaporama;
	unsigned short int mPositionDansImagesChargees;
};

class Diaporama
{
private:
	// PROPRIETES
	// identifiant du diaporama
	unsigned short int mIdentifiantDiaporama;
	// titre du diaporama
	string mTitreDiaporama;
	// vitesse de defilement
	unsigned short int mVitesseDefilement=2000;
	// vecteur de la position des images dans le diaporama et dans le vecteur images chargees du lecteur
	vector<LocalisationsImagesDiaporama> mLocalisationsImagesDiaporama;
public:
	// CONSTRUCTEURS
	Diaporama(unsigned short int, string, unsigned short int,
		vector<LocalisationsImagesDiaporama>);
	// DESCTRUCTEUR
	~Diaporama();

	// GETTERS & SETTERS
	// renvoie l'identifiant du diaporama
	unsigned short int getIdentifiantDiaporama() const;
	// modifie l'identifiant du diaporama
	void setIdentifiantDiaporama(unsigned short int);

	// renvoie le titre du diaporama
	string getTitreDiaporama() const;
	// modifie le titre du diaporama
	void setTitreDiaporama(string);

	// renvoie la vitesse de defilement du diaporama
	unsigned short int getVitesseDefilement() const;
	// modifie la vitesse de defilement du diaporama
	void setVitesseDefilement(unsigned short int);

	// renvoie le membre mLocalisationsImagesDiaporama
	vector<LocalisationsImagesDiaporama> getLocalisationsImagesDiaporama() const;
	// modifie le membre mLocalisationsImagesDiaporama
	void setLocalisationsImagesDiaporama(vector<LocalisationsImagesDiaporama>);

	// renvoie la position d'une image en connaissant sa position dans mLocalisationsImagesDiaporama
	LocalisationsImagesDiaporama getPosImageDansDiapo(unsigned short int) const;
	// modifie la position d'une image � un certain index en connaissant sa position dans mLocalisationsImagesDiaporama
	void setPosImageDansDiapo(unsigned short int, LocalisationsImagesDiaporama);
	
	// renvoie le nombre d'images � partir de mLocalisationsImagesDiaporama
	unsigned int nbImages() const;

	// METHODES MEMBRES
	// push back un objet LocalisationsImagesDiaporama au membre mLocalisationsImagesDiaporama
	void pushBackLocalisationsImagesDansDiaporama(LocalisationsImagesDiaporama);
	// modifie mIdentifiantDiaporama, mTitreDiaporama, mVitesseDefilement et mLocalisationsImagesDiaporama avec les valeurs des param�tres
	void changerValeursMembres(unsigned short int, string, unsigned short int, vector<LocalisationsImagesDiaporama>);
	// permet d'avancer jusqu'� la prochaine image
	void avancer(unsigned int& pPosImageCourante) const;
	// permet de reculer jusqu'� la pr�c�dente image
	void reculer(unsigned int& pPosImageCourante) const;
};

#endif