#ifndef IMAGE_H
#define IMAGE_H

#include <string>

using std::string;

class Image
{
private:
	// PROPRIETES
	// identifiant de l'image
	unsigned short int mIdentifiantImage;
	// titre de l'image
	string mTitreImage;
	// categorie de l'image
	string mCategorieImage;
	// chemin absolu de l'image
	string mCheminImage;
public:
	// CONSTRUCTEURS
	// constructeur par d�faut
	Image(unsigned short int, string, string, string);
	// DESTRUCTEUR
	~Image();

	// GETTERS & SETTERS
	// renvoie l'identifiant de l'image
	unsigned short int getIdentifiantImage() const;
	// modifie l'identifiant de l'image
	void setIdentifiantImage(unsigned short int);
	// renvoie le titre de l'image
	string getTitreImage() const;
	// modifie le titre de l'image
	void setTitreImage(string);

	// renvoie la categorie de l'image
	string getCategorieImage() const;
	// modifie la categorie de l'image
	void setCategorieImage(string);

	// renvoie le chemin absolu de l'image
	string getCheminImage() const;
	// modifie le chemin absolu de l'image
	void setCheminImage(string);

	// METHODES MEMBRES
	// modifie mIdentifiantImage, mTitreImage, mCategorieImage et mCheminImage avec les valeurs des param�tres
	void changerValeursMembres(unsigned short int, string, string, string);
	// permet d'afficher une image
	void afficher() const;
};

#endif