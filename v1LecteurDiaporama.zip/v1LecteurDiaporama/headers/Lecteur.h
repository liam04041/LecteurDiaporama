#ifndef LECTEUR_H
#define LECTEUR_H

#include <vector>
#include "Diaporama.h"

using std::vector;

// modes du lecteur
// ModeManuel=0 : lecteur manuel
// ModeAuto=1 : lecteur automatique
enum ModeLecteur { ModeManuel=0, ModeAuto=1 };

// etats du lecteur
// Inactif=0 : lecteur inactif
// Actif=1 : lecteur actif
enum EtatLecteur { Inactif=0, Actif=1 };

// etats de chargement du lecteur
// Vide=0 : lecteur vide
// Charge=1 : diaporama charge
enum EtatChargementLecteur { Vide=0, Charge=1 };

class Lecteur
{
private:
	// PROPRIETES
	// etat du lecteur
	EtatLecteur mEtatLecteur;
	// mode du lecteur
	ModeLecteur mModeLecteur = ModeManuel;
	// etat de chargement du lecteur
	EtatChargementLecteur mEtatChargementLecteur = Vide;

	// position index du diaporama courant du le lecteur
	unsigned short int mPosDiaporamaCourant;
	// position image courante du lecteur
	unsigned short int mPosImageCourante;
	// vecteur des diaporamas
	vector<Diaporama> mListeDiaporamasCharges;
	// vecteur des images du lecteur
	vector<Image> mListeImagesChargees;
public:
	// CONSTRUCTEUR
	// constructeur par d�faut
	Lecteur(EtatLecteur,
		unsigned short int, unsigned short int,
		vector<Diaporama>, vector<Image>);
	// DESCTRUCTEUR
	~Lecteur();

	// GETTERS & SETTERS
	// renvoie l'etat du lecteur
	EtatLecteur getEtatLecteur() const;
	// modifie l'etat du lecteur
	void setEtatLecteur(EtatLecteur);

	// renvoie le mode du lecteur
	ModeLecteur getModeLecteur() const;
	// modifie le mode du lecteur
	void setModeLecteur(ModeLecteur);

	// renvoie l'etat de chargement du lecteur
	EtatChargementLecteur getEtatChargementLecteur() const;
	// modifie l'etat de chargement du lecteur
	void setEtatChargementLecteur(EtatChargementLecteur);

	// renvoie le diaporama courant
	unsigned short int getPosDiaporamaCourant() const;
	// modifie le diaporama courant
	void setPosDiaporamaCourant(unsigned short int);

	// renvoie l'image ocurante
	unsigned short int getPosImageCourante() const;
	// modifie l'image courante
	void setPosImageCourante(unsigned short int);

	// renvoie la liste des diaporamas charg�s
	vector<Diaporama> getListeDiaporamasCharges() const;
	// modifie la liste des diaporamas charg�s
	void setListeDiaporamasCharges(vector<Diaporama>);

	// renvoie la liste des images charg�es
	vector<Image> getListeImagesChargees() const;
	// modifie la liste des images charg�es
	void setListeImagesChargees(vector <Image>);

	// METHODES MEMBRES
	// charge les images (ajoute des objets Image au vecteur en param�tre et initialise les objets
	void chargerImages(vector<Image>&);
	// charge les diaporamas (ajoute des objets Diaporama au vecteur en param�tre et initialise les objets
	void chargerDiaporamas(vector<Diaporama>&);
	// tri le diaporama par ordre croissant des rang avec un tri � bulle
	void triCroissantRang(Diaporama&);
	// affiche l'image courante
	void afficherImageCouranteDansDiaporamaCourant(Diaporama&, unsigned int, Image&);
};

#endif