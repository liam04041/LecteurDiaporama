#include "Diaporama.h"
#include <iostream>

using std::cout;
using std::endl;


// CONSTRUCTEURS
// constructeur personnalis�
Diaporama::Diaporama(unsigned short int pIdentifiantDiaporama, string pTitreDiaporama, unsigned short int pVitesseDefilement,
	vector<LocalisationsImagesDiaporama> pLocalisationsImagesDiaporama) :
	mIdentifiantDiaporama(pIdentifiantDiaporama), mTitreDiaporama(pTitreDiaporama),
	mLocalisationsImagesDiaporama(pLocalisationsImagesDiaporama), mVitesseDefilement(pVitesseDefilement)
{ cout << "Constructeur Diaporama personnalis�" << endl; }
// DESTRUCTEUR
Diaporama::~Diaporama() { };

// GETTERS & SETTERS
unsigned short int Diaporama::getIdentifiantDiaporama() const { return mIdentifiantDiaporama; }
void Diaporama::setIdentifiantDiaporama(unsigned short int pNewIdentifiantDiaporama) { mIdentifiantDiaporama = pNewIdentifiantDiaporama; }

string Diaporama::getTitreDiaporama() const { return mTitreDiaporama; }
void Diaporama::setTitreDiaporama(string pNewTitreDiaporama) { mTitreDiaporama = pNewTitreDiaporama; }

unsigned short int Diaporama::getVitesseDefilement() const { return mVitesseDefilement; }
void Diaporama::setVitesseDefilement(unsigned short int pNewVitesseDefilement) { mVitesseDefilement = pNewVitesseDefilement; }

vector<LocalisationsImagesDiaporama> Diaporama::getLocalisationsImagesDiaporama() const { return mLocalisationsImagesDiaporama; }
void Diaporama::setLocalisationsImagesDiaporama(vector<LocalisationsImagesDiaporama> pNewLocalisationsImagesDiaporama) { mLocalisationsImagesDiaporama = pNewLocalisationsImagesDiaporama; }

LocalisationsImagesDiaporama Diaporama::getPosImageDansDiapo(unsigned short int pIndex) const { return mLocalisationsImagesDiaporama[pIndex]; }
void Diaporama::setPosImageDansDiapo(unsigned short int pIndex, LocalisationsImagesDiaporama pLocalisation) { this->mLocalisationsImagesDiaporama[pIndex] = pLocalisation; }

unsigned int Diaporama::nbImages() const
{
	return static_cast<unsigned int>(this->getLocalisationsImagesDiaporama().size());
}

// METHODES MEMBRES
void Diaporama::pushBackLocalisationsImagesDansDiaporama(LocalisationsImagesDiaporama pLocalisationsImagesDiaporama)
{
	this->mLocalisationsImagesDiaporama.push_back(pLocalisationsImagesDiaporama);
}

void Diaporama::changerValeursMembres(unsigned short int pNewIdentifiantDiaporama, string pNewTitreDiaporama,
	unsigned short int pNewVitesseDefilement, vector<LocalisationsImagesDiaporama> pNewLocalisationsImagesDiaporama)
{
	this->setIdentifiantDiaporama(pNewIdentifiantDiaporama);
	this->setTitreDiaporama(pNewTitreDiaporama);
	this->setVitesseDefilement(pNewVitesseDefilement);
	this->setLocalisationsImagesDiaporama(pNewLocalisationsImagesDiaporama);
}

void Diaporama::avancer(unsigned int& pPosImageCourante) const
{
	if (pPosImageCourante == this->getLocalisationsImagesDiaporama().size() - 1)
	{
		pPosImageCourante = 0;
	}
	else {
		pPosImageCourante++;
	}
}

void Diaporama::reculer(unsigned int& pPosImageCourante) const
{
	if (pPosImageCourante == 0)
	{
		pPosImageCourante = static_cast<unsigned int>(this->getLocalisationsImagesDiaporama().size()) - 1;
	}
	else {
		pPosImageCourante--;
	}
}

