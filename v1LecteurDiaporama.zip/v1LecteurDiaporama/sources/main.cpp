#include <iostream>
#include "Diaporama.h"
#include "Lecteur.h"
#include "Image.h"

using std::cout;
using std::cin;
using std::endl;


void saisieVerifChoixActionSurImageCourante(char&);

void declencherAction(char, vector<Diaporama>&,
	unsigned int&, unsigned int&, vector<Image>&, Lecteur&);

unsigned int saisieVerifChoixDiaporama(vector<Diaporama>&);


int main()
{

	vector<Image> ImagesChargees;
	vector<Diaporama> DiaporamasCharges;
	Lecteur UnLecteur(Actif, 0, 0, DiaporamasCharges, ImagesChargees);


	UnLecteur.chargerImages(ImagesChargees);
	UnLecteur.chargerDiaporamas(DiaporamasCharges);

	unsigned int tailleImages= static_cast<unsigned int>(UnLecteur.getListeImagesChargees().size());
	unsigned short int tailleDiaporamas = static_cast<unsigned short int>(UnLecteur.getListeDiaporamasCharges().size());

	for (unsigned int posDiaporamas = 0; posDiaporamas < tailleDiaporamas; posDiaporamas++)
	{
		UnLecteur.triCroissantRang(UnLecteur.getListeDiaporamasCharges()[posDiaporamas]);
	}

	unsigned int idDiaporamaCourant=0;
	unsigned int idImageCourante=0;

	char choixAction;

	while (true)
	{
		system("cls");
		unsigned int position=DiaporamasCharges[idDiaporamaCourant].getLocalisationsImagesDiaporama()[idImageCourante].mPositionDansImagesChargees;
		UnLecteur.afficherImageCouranteDansDiaporamaCourant(DiaporamasCharges[idDiaporamaCourant], idImageCourante, ImagesChargees[position]);

		saisieVerifChoixActionSurImageCourante(choixAction);
		if (choixAction == 'Q') { break; }

		system("cls");
		declencherAction(choixAction, DiaporamasCharges, idDiaporamaCourant, idImageCourante, ImagesChargees, UnLecteur);
	}

	cout << "Au revoir" << endl;
	return 0;
}


void declencherAction(char pChoixAction, vector<Diaporama>& pDiaporamasCharges,
	unsigned int& pIdDiaporamaCourant, unsigned int& pIdImageCourante, vector<Image>& pImagesChargees, Lecteur& pUnLecteur)
{
	unsigned int position;
	unsigned int choixDiaporama;
	switch (pChoixAction)
	{
	case 'A':
		pDiaporamasCharges[pIdDiaporamaCourant].avancer(pIdImageCourante);
		position = pDiaporamasCharges[pIdDiaporamaCourant].getLocalisationsImagesDiaporama()[pIdImageCourante].mPositionDansImagesChargees;
		pUnLecteur.afficherImageCouranteDansDiaporamaCourant(pDiaporamasCharges[pIdDiaporamaCourant], pIdImageCourante, pImagesChargees[position]);
		break;
	case 'R':
		pDiaporamasCharges[pIdDiaporamaCourant].reculer(pIdImageCourante);
		position = pDiaporamasCharges[pIdDiaporamaCourant].getLocalisationsImagesDiaporama()[pIdImageCourante].mPositionDansImagesChargees;
		pUnLecteur.afficherImageCouranteDansDiaporamaCourant(pDiaporamasCharges[pIdDiaporamaCourant], pIdImageCourante, pImagesChargees[position]);
		break;
	case 'C':
		cout << "Choisissez un diaporama " << endl;
		choixDiaporama = saisieVerifChoixDiaporama(pDiaporamasCharges);
		pIdDiaporamaCourant = choixDiaporama;
		pIdImageCourante = 0;
		break;
	default: break;
	}
}

void saisieVerifChoixActionSurImageCourante(char& pChoixAction)
{
	cout << endl << endl;
	while (true)
	{
		cout << "ACTIONS :" << " A-vancer" << " R-eculer" << " C-hanger de diaporama " << " Q-uitter .......  votre choix ? ";
		cin >> pChoixAction;
		pChoixAction = toupper(pChoixAction);
		if ((pChoixAction == 'A') || (pChoixAction == 'R') || (pChoixAction == 'C') || (pChoixAction == 'Q'))
		{
			break;
		}
	}
}

unsigned int saisieVerifChoixDiaporama(vector<Diaporama>& pDiaporamasCharges)
{
	unsigned int choixSaisi;
	int choixDiaporama;
	while (true)
	{
		system("cls");
		cout << endl << endl << "CHANGEMENT DIAPORAMA : " << endl;
		for (unsigned int num = 0; num < pDiaporamasCharges.size(); num++)
		{
			cout << num << " : " << pDiaporamasCharges[num].getTitreDiaporama() << endl;
			if(num!=pDiaporamasCharges.size()-1) { cout << endl; }
		}

		cout << ".......  votre choix ? "; cin >> choixSaisi;
		choixDiaporama = choixSaisi;

		if ((choixDiaporama >= 1) && (choixDiaporama < pDiaporamasCharges.size()))
		{
			break;
		}
	}
	return choixDiaporama;
}






