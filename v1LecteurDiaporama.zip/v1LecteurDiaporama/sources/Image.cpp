#include "Image.h"
#include <iostream>

using std::cout;
using std::endl;
	
// CONSTRUCTEURS
// constructeur par d�faut
Image::Image(unsigned short int pIdentifiantImage, string pTitreImage, string pCategorieImage, string pCheminImage) :
	mIdentifiantImage(pIdentifiantImage), mTitreImage(pTitreImage), mCategorieImage(pCategorieImage), mCheminImage(pCheminImage)
{ cout << "Constructeur Image par d�faut" << endl; }
// DESCTRUCTEUR
Image::~Image() { };

// GETTERS & SETTERS
unsigned short int Image::getIdentifiantImage() const { return mIdentifiantImage; }
void Image::setIdentifiantImage(unsigned short int pNewIdentifiantImage) { mIdentifiantImage = pNewIdentifiantImage; }

string Image::getTitreImage() const { return mTitreImage; }
void Image::setTitreImage(string pNewTitreImage) { mTitreImage = pNewTitreImage; }

string Image::getCategorieImage() const { return mCategorieImage; }
void Image::setCategorieImage(string pNewCategorieImage) { mCategorieImage = pNewCategorieImage; }

string Image::getCheminImage() const { return mCheminImage; }
void Image::setCheminImage(string pNewCheminImage) { mCheminImage = pNewCheminImage; }

// METHODES MEMBRES
void Image::changerValeursMembres(unsigned short int pNewIdentifiantImage, string pNewTitreImage,
	string pNewCategorieImage, string pNewCheminImage)
{
	this->setIdentifiantImage(pNewIdentifiantImage);
	this->setTitreImage(pNewTitreImage);
	this->setCategorieImage(pNewCategorieImage);
	this->setCheminImage(pNewCheminImage);
}

void Image::afficher() const
{
	cout << "image(titre:" << this->getTitreImage()
		<< ", categorie:" << this->getCategorieImage()
		<< ", chemin:" << this->getCheminImage() << ")" << endl;
}
