#include "Lecteur.h"
#include <iostream>

using std::cout;
using std::cin;
using std::endl;

// CONSTRUCTEUR
// constructeur par defaut
Lecteur::Lecteur(EtatLecteur pEtatLecteur,
	unsigned short int pPosDiaporamaCourant, unsigned short int pPosImageCourante,
	vector<Diaporama> pListeDiaporamasCharges, vector<Image> pListeImagesChargees) :
	mEtatLecteur(pEtatLecteur),
	mPosDiaporamaCourant(pPosDiaporamaCourant), mPosImageCourante(pPosImageCourante),
	mListeDiaporamasCharges(pListeDiaporamasCharges), mListeImagesChargees(pListeImagesChargees)
{ cout << "Constructeur Lecteur par d�faut" << endl; }
// DESTRUCTEUR
Lecteur::~Lecteur() { };

// GETTERS & SETTERS
EtatLecteur Lecteur::getEtatLecteur() const { return mEtatLecteur; }
void Lecteur::setEtatLecteur(EtatLecteur pNewEtatLecteur) { mEtatLecteur = pNewEtatLecteur; }

ModeLecteur Lecteur::getModeLecteur() const { return mModeLecteur; }
void Lecteur::setModeLecteur(ModeLecteur pNewModeLecteur) { mModeLecteur = pNewModeLecteur; }

EtatChargementLecteur Lecteur::getEtatChargementLecteur() const { return mEtatChargementLecteur; }
void Lecteur::setEtatChargementLecteur(EtatChargementLecteur pNewEtatChargementLecteur) { mEtatChargementLecteur = pNewEtatChargementLecteur; }

unsigned short int Lecteur::getPosDiaporamaCourant() const { return mPosDiaporamaCourant; }
void Lecteur::setPosDiaporamaCourant(unsigned short int pNewPosDiaporamaCourant) { mPosDiaporamaCourant = pNewPosDiaporamaCourant; }

unsigned short int Lecteur::getPosImageCourante() const { return mPosImageCourante; }
void Lecteur::setPosImageCourante(unsigned short int pNewPosImageCourante) { mPosImageCourante = pNewPosImageCourante; }

vector<Diaporama> Lecteur::getListeDiaporamasCharges() const { return mListeDiaporamasCharges; }
void Lecteur::setListeDiaporamasCharges(vector<Diaporama> pNewListeDiaporamasCharges) { mListeDiaporamasCharges = pNewListeDiaporamasCharges; }

vector<Image> Lecteur::getListeImagesChargees() const { return mListeImagesChargees; }
void Lecteur::setListeImagesChargees(vector<Image> pNewListeImagesChargees) { mListeImagesChargees = pNewListeImagesChargees; }

// METHODES MEMBRES
void Lecteur::chargerImages(vector<Image>& pImagesACharger)
{
	Image ImageACharger(0, "", "objet", "C:\\cartesDisney\\Disney_tapis.gif");
	pImagesACharger.push_back(ImageACharger);
	ImageACharger.changerValeursMembres(1, "Blanche Neige", "personnage", "C:\\cartesDisney\\Disney_4.gif");
	pImagesACharger.push_back(ImageACharger);
	ImageACharger.changerValeursMembres(2, "Alice", "personnage", "C:\\cartesDisney\\Disney_2.gif");
	pImagesACharger.push_back(ImageACharger);
	ImageACharger.changerValeursMembres(3, "Mickey", "animal", "C:\\cartesDisney\\Disney_19.gif");
	pImagesACharger.push_back(ImageACharger);
	ImageACharger.changerValeursMembres(4, "Pinnochio", "personnage", "C:\\cartesDisney\\Disney_29.gif");
	pImagesACharger.push_back(ImageACharger);
	ImageACharger.changerValeursMembres(5, "chateau", "objet", "C:\\cartesDisney\\Disney_0.gif");
	pImagesACharger.push_back(ImageACharger);
	ImageACharger.changerValeursMembres(6, "Minnie", "personnage", "C:\\cartesDisney\\Disney_14.gif");
	pImagesACharger.push_back(ImageACharger);
	ImageACharger.changerValeursMembres(7, "Bambi", "animal", "C:\\cartesDisney\\Disney_3.gif");
	pImagesACharger.push_back(ImageACharger);
}

void Lecteur::chargerDiaporamas(vector<Diaporama>& pDiaporamasACharger)
{
	LocalisationsImagesDiaporama ImageDansDiaporama{};

	// diapo d�faut
	ImageDansDiaporama.mPositionDansImagesChargees = 0;
	ImageDansDiaporama.mPositionDansDiaporama = 1;
	Diaporama DiaporamaACharger(0, "Diaporama par defaut", 1, vector<LocalisationsImagesDiaporama>());
	DiaporamaACharger.pushBackLocalisationsImagesDansDiaporama(ImageDansDiaporama);
	pDiaporamasACharger.push_back(DiaporamaACharger);

	// diapo pantxika
	DiaporamaACharger.changerValeursMembres(1, "Diaporama pantxika", 2, vector<LocalisationsImagesDiaporama>());
	ImageDansDiaporama.mPositionDansImagesChargees = 4;
	ImageDansDiaporama.mPositionDansDiaporama = 3;
	DiaporamaACharger.pushBackLocalisationsImagesDansDiaporama(ImageDansDiaporama);
	ImageDansDiaporama.mPositionDansImagesChargees = 1;
	ImageDansDiaporama.mPositionDansDiaporama = 2;
	DiaporamaACharger.pushBackLocalisationsImagesDansDiaporama(ImageDansDiaporama);
	ImageDansDiaporama.mPositionDansImagesChargees = 2;
	ImageDansDiaporama.mPositionDansDiaporama = 4;
	DiaporamaACharger.pushBackLocalisationsImagesDansDiaporama(ImageDansDiaporama);
	ImageDansDiaporama.mPositionDansImagesChargees = 3;
	ImageDansDiaporama.mPositionDansDiaporama = 1;
	DiaporamaACharger.pushBackLocalisationsImagesDansDiaporama(ImageDansDiaporama);
	pDiaporamasACharger.push_back(DiaporamaACharger);
	
	// diapo thierry
	DiaporamaACharger.changerValeursMembres(2, "Diaporama Thierry", 4, vector<LocalisationsImagesDiaporama>());
	ImageDansDiaporama.mPositionDansImagesChargees = 4;
	ImageDansDiaporama.mPositionDansDiaporama = 1;
	DiaporamaACharger.pushBackLocalisationsImagesDansDiaporama(ImageDansDiaporama);
	ImageDansDiaporama.mPositionDansImagesChargees = 1;
	ImageDansDiaporama.mPositionDansDiaporama = 2;
	DiaporamaACharger.pushBackLocalisationsImagesDansDiaporama(ImageDansDiaporama);
	ImageDansDiaporama.mPositionDansImagesChargees = 2;
	ImageDansDiaporama.mPositionDansDiaporama = 3;
	DiaporamaACharger.pushBackLocalisationsImagesDansDiaporama(ImageDansDiaporama);
	ImageDansDiaporama.mPositionDansImagesChargees = 3;
	ImageDansDiaporama.mPositionDansDiaporama = 4;
	DiaporamaACharger.pushBackLocalisationsImagesDansDiaporama(ImageDansDiaporama);
	pDiaporamasACharger.push_back(DiaporamaACharger);

	// diapo yann
	DiaporamaACharger.changerValeursMembres(3, "Diaporama Yann", 3, vector<LocalisationsImagesDiaporama>());
	ImageDansDiaporama.mPositionDansImagesChargees = 4;
	ImageDansDiaporama.mPositionDansDiaporama = 2;
	DiaporamaACharger.pushBackLocalisationsImagesDansDiaporama(ImageDansDiaporama);
	ImageDansDiaporama.mPositionDansImagesChargees = 1;
	ImageDansDiaporama.mPositionDansDiaporama = 1;
	DiaporamaACharger.pushBackLocalisationsImagesDansDiaporama(ImageDansDiaporama);
	ImageDansDiaporama.mPositionDansImagesChargees = 2;
	ImageDansDiaporama.mPositionDansDiaporama = 4;
	DiaporamaACharger.pushBackLocalisationsImagesDansDiaporama(ImageDansDiaporama);
	ImageDansDiaporama.mPositionDansImagesChargees = 3;
	ImageDansDiaporama.mPositionDansDiaporama = 3;
	DiaporamaACharger.pushBackLocalisationsImagesDansDiaporama(ImageDansDiaporama);
	pDiaporamasACharger.push_back(DiaporamaACharger);

	// diapo manu
	DiaporamaACharger.changerValeursMembres(4, "Diaporama Manu", 1, vector<LocalisationsImagesDiaporama>());
	ImageDansDiaporama.mPositionDansImagesChargees = 4;
	ImageDansDiaporama.mPositionDansDiaporama = 4;
	DiaporamaACharger.pushBackLocalisationsImagesDansDiaporama(ImageDansDiaporama);
	ImageDansDiaporama.mPositionDansImagesChargees = 1;
	ImageDansDiaporama.mPositionDansDiaporama = 3;
	DiaporamaACharger.pushBackLocalisationsImagesDansDiaporama(ImageDansDiaporama);
	ImageDansDiaporama.mPositionDansImagesChargees = 2;
	ImageDansDiaporama.mPositionDansDiaporama = 2;
	DiaporamaACharger.pushBackLocalisationsImagesDansDiaporama(ImageDansDiaporama);
	ImageDansDiaporama.mPositionDansImagesChargees = 3;
	ImageDansDiaporama.mPositionDansDiaporama = 1;
	DiaporamaACharger.pushBackLocalisationsImagesDansDiaporama(ImageDansDiaporama);
	pDiaporamasACharger.push_back(DiaporamaACharger);
}

void Lecteur::triCroissantRang(Diaporama& pDiaporama)
{
	unsigned int taille = static_cast<unsigned int>(pDiaporama.getLocalisationsImagesDiaporama().size());
	LocalisationsImagesDiaporama ImageDansDiaporama;
	for (unsigned int ici = taille - 1; ici >= 1; ici--)
	{
		for (unsigned int i = 0; i < ici; i++)
		{
			if (pDiaporama.getLocalisationsImagesDiaporama()[i].mPositionDansDiaporama > pDiaporama.getLocalisationsImagesDiaporama()[i + 1].mPositionDansDiaporama)
			{
				ImageDansDiaporama = pDiaporama.getLocalisationsImagesDiaporama()[i];
				pDiaporama.setPosImageDansDiapo(i, pDiaporama.getLocalisationsImagesDiaporama()[i + 1]);
				pDiaporama.setPosImageDansDiapo(i + 1, ImageDansDiaporama);
			}
		}
	}
}

void Lecteur::afficherImageCouranteDansDiaporamaCourant(Diaporama& pDiaporamaCourant, unsigned int pIdImageCourante, Image& pImage)
{
	cout << endl << endl;
	cout << "DIAPORAMA : " << pDiaporamaCourant.getTitreDiaporama() << endl << endl;
	cout << pDiaporamaCourant.getLocalisationsImagesDiaporama()[pIdImageCourante].mPositionDansDiaporama << " sur " << pDiaporamaCourant.nbImages() << " / ";
	pImage.afficher();
}




