#include "lecteurvue.h"
#include "ui_lecteurvue.h"
#include <QDebug>
#include <QApplication>

LecteurVue::LecteurVue(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::LecteurVue)
{
    ui->setupUi(this);

    // Connexion Button_Suivant
    QObject::connect(ui->Button_Suivant, SIGNAL(clicked()),
                     this, SLOT(imageSuivante()));

    // Connexion Button_Precedent
    QObject::connect(ui->Button_Precedent, SIGNAL(clicked()),
                     this, SLOT(imagePrecedente()));

    // Connexion Button_Lancer
    QObject::connect(ui->Button_Lancer, SIGNAL(clicked()),
                     this, SLOT(lancerDiapo()));

    // Connexion Action_Arreter
    QObject::connect(ui->Button_Arreter, SIGNAL(clicked()),
                     this, SLOT(arreterDiapo()));

    // Connexion Action_A_Propos_De
    QObject::connect(ui->Action_A_Propos_De, SIGNAL(triggered()),
                     this, SLOT(afficherAProposDe()));

    // Connexion Action_Enlever_Diapo
    QObject::connect(ui->Action_Enlever_Diaporama, SIGNAL(triggered()),
                     this, SLOT(enleverDiapoLecteur()));

    // Connexion Action_Vitesse_Defilement
    QObject::connect(ui->Action_Vitesse_Defilement, SIGNAL(triggered()),
                     this, SLOT(demanderNouvelleVitesse()));

    // Connexion Action_Quitter
    QObject::connect(ui->Action_Quitter, SIGNAL(triggered()),
                     this, SLOT(quitterApp()));

    // Connexion Action_Filtrer_Images
    QObject::connect(ui->Action_Charger_Diaporama, SIGNAL(triggered()),
                     this, SLOT(chargerDiaporama()));

    modeManuel();
}

LecteurVue::~LecteurVue()
{
    delete ui;
}

void LecteurVue::imageSuivante() {
    if (this->ModeLectManuel == false) {
        qDebug() << "Arret du diaporama";
        modeManuel();
    }
    else {
        qDebug() << "Passage à l'image suivante";
    }
}

void LecteurVue::imagePrecedente() {
    if (this->ModeLectManuel == false) {
        qDebug() << "Arret du diaporama";
        modeManuel();
    }
    else {
        qDebug() << "Passage à l'image précédente";
    }
}

void LecteurVue::afficherAProposDe() {
    qDebug() << "Affichage dialog à propos de";
}

void LecteurVue::enleverDiapoLecteur() {
    qDebug() << "Retrait du diapo. actuel du lecteur";
}

void LecteurVue::demanderNouvelleVitesse() {
    qDebug() << "Ouverture dialog choix vitesse";
}

void LecteurVue::quitterApp() {
    qDebug() << "Fermeture de l'app...";
    QApplication::exit();
}

void LecteurVue::lancerDiapo() {
    if (this->ModeLectManuel == true) {
        modeAuto();
    }
    qDebug() << "(Re)Démarrage du diaporama";
}

void LecteurVue::arreterDiapo() {
    qDebug() << "Arret du diaporama";
    modeManuel();
}

void LecteurVue::chargerDiaporama() {
    qDebug() << "Chargement du diaporama :" << ui->LE_Filtre_Diapo->text();
}

void LecteurVue::modeAuto() {
    ui->statusbar->showMessage("Mode de lecture actuel : Automatique");
    ModeLectManuel = false;

    ui->Button_Arreter->setEnabled(true);

    // Debug
    qDebug() << "Passage en mode automatique";
}

void LecteurVue::modeManuel() {
    ui->statusbar->showMessage("Mode de lecture actuel : Manuel");
    ModeLectManuel = true;

    ui->Button_Arreter->setEnabled(false);

    // Debug
    qDebug() << "Passage en mode manuel";
}
