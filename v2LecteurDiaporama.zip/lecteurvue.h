#ifndef LECTEURVUE_H
#define LECTEURVUE_H

#include <QMainWindow>
#include <QObject>

QT_BEGIN_NAMESPACE
namespace Ui {
class LecteurVue;
}
QT_END_NAMESPACE

class LecteurVue : public QMainWindow
{
    Q_OBJECT

public:
    LecteurVue(QWidget *parent = nullptr);
    ~LecteurVue();
public slots:
    void imageSuivante();
    void imagePrecedente();
    void afficherAProposDe();
    void enleverDiapoLecteur();
    void demanderNouvelleVitesse();
    void quitterApp();
    void lancerDiapo();
    void arreterDiapo();
    void chargerDiaporama();
private:
    Ui::LecteurVue *ui;
    bool ModeLectManuel = true;

    void modeAuto();
    void modeManuel();
};
#endif // LECTEURVUE_H
